let mediaRecorder = null;
let audioChunks = [];

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const target = message.target || message.to;

  if (target !== "offscreen") {
    return;
  }

  const action = message.action || message.type;

  if (action === "INIT_RECORDING") {
    startCapture(message.streamId);
  }

  if (action === "FINALIZE_RECORDING") {
    stopAndUpload(sendResponse);
    return true; // Keep the message channel open
  }
});

async function startCapture(streamId) {
  try {
    audioChunks = [];

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId,
        },
      },
      video: false,
    });

    // Continue playing audio while recording
    const audioContext = new AudioContext();
    const source = audioContext.createMediaStreamSource(stream);
    source.connect(audioContext.destination);

    mediaRecorder = new MediaRecorder(stream, {
      mimeType: "audio/webm",
    });

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        audioChunks.push(event.data);
      }
    };

    mediaRecorder.start(1000);

    console.log("Recording started...");
  } catch (error) {
    console.error("Error starting recording:", error);
  }
}

function stopAndUpload(sendResponse) {
  if (!mediaRecorder || mediaRecorder.state === "inactive") {
    sendResponse({
      success: false,
      error: "No active recording found",
    });
    return;
  }

  mediaRecorder.onstop = async () => {
    try {
      const audioBlob = new Blob(audioChunks, {
        type: "audio/webm",
      });

      const formData = new FormData();

      // Backend requires these two fields
      formData.append("file", audioBlob, "meeting.webm");
      formData.append(
        "email",
        "nithiyasri.d.2023.cse@ritchennai.edu.in"
      );

      const response = await fetch(
        "http://localhost:8000/api/meetings/upload-audio",
        {
          method: "POST",
          body: formData,
        }
      );

      const result = await response.text();

      console.log("Status:", response.status);
      console.log("Response:", result);

      if (response.ok) {
        sendResponse({
          success: true,
          message: "Upload successful",
        });
      } else {
        sendResponse({
          success: false,
          error: `Upload failed (${response.status})`,
        });
      }
    } catch (error) {
      console.error("Upload Error:", error);

      sendResponse({
        success: false,
        error: error.message,
      });
    }
  };

  mediaRecorder.stop();

  mediaRecorder.stream
    .getTracks()
    .forEach((track) => track.stop());
}